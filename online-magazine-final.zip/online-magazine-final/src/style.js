// $(document).ready(function(){
//     $("#onclick-btn").click(function(){
//         var = document.createElement("<div>");

//     });
// });
$(document).ready(function(){
	$("#buy-btn").click(function(){
		$("#myModal").modal();
	});
});
$(document).ready(function() {
     
            $(".active").click(function() {
               $(".search-box").toggle();
               $("input[type='text']").focus();
             });
 
        });
// $(document).ready(function(){
// 	$("#my-search").click(function(){
// 		$("#search").show(function(){
// 			$("#search").css("display": "inline-block");
// 		});
// 	});
// });
